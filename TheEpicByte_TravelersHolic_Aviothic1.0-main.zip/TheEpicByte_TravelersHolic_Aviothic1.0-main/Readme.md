# Project profile
1. Project Defination :-

   1: Our Team Creating a website That Help Tourist To Find Out The Best Place For Going To a Trip.

   2: Our Website Name is Travelers Holic.

   3: Our Website empowers the travelers experience and  Easy For Visiter To Find The Best Place in the country or state to enjoy and explore. 

# System Enviroment
1.Frontend Tools  :-
     
   1: We have used Three  computer Languages.

      1: HTML.

      2: CSS.

      3: JAVASCRIPT.

# System Developing Strategy
  System Development Module :-

    1:Prototype Model :-
        We use prototype model in our website that built with minimal requirements. This prototype is then tested and modified based on the feedback received from the client until a final prototype with desired functionalities gets created.

# Design Or Screenshot

Screenshot 1:

![Alt text](img..jpeg "a title")

Screenshot 2:

![Alt text](new1.jpeg "a title")




